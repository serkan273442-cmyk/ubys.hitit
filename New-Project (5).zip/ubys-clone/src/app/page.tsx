"use client";

import { useState } from "react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { User, Lock, Menu } from "lucide-react";
import { useRouter } from "next/navigation";
import Image from "next/image";

export default function LoginPage() {
  const router = useRouter();
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();

    // Giriş kontrolü
    if (username === "224511057" && password === "fifa2014") {
      // Başarılı giriş
      router.push("/dashboard");
    } else {
      // Hatalı giriş
      setError("Kullanıcı adı veya şifre hatalı!");
    }
  };

  return (
    <div className="min-h-screen flex flex-col" style={{ background: "linear-gradient(135deg, #668ebd 0%, #8faed3 100%)" }}>
      {/* Header */}
      <header
        className="h-[50px] flex items-center justify-between px-4"
        style={{ background: "rgba(61, 139, 184, 0.5)" }}
      >
        <button className="flex items-center gap-2 text-sm text-white hover:opacity-80">
          <Menu className="w-4 h-4" />
          <span style={{ fontSize: "13px", fontWeight: 400 }}>MENÜ</span>
        </button>
        <div className="flex items-center gap-6">
          <a href="#" className="text-white text-sm hover:underline" style={{ fontSize: "13px" }}>Hakkımızda..</a>
          <a href="#" className="text-white text-sm hover:underline" style={{ fontSize: "13px" }}>Duyurular</a>
          <button className="text-white hover:opacity-80">
            <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
              <circle cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="1.5" fill="none"/>
              <path d="M12 2a10 10 0 0 1 0 20"/>
            </svg>
          </button>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 flex items-center justify-center px-4 py-12">
        <div
          className="w-full max-w-[360px]"
          style={{
            background: "#FFFFFF",
            boxShadow: "0 2px 15px rgba(0,0,0,0.1)",
            padding: "40px 30px"
          }}
        >
          {/* Logo */}
          <div className="flex justify-center mb-8">
            <Image
              src="https://ext.same-assets.com/1851312571/84350226.png"
              alt="Hitit Üniversitesi"
              width={160}
              height={80}
              style={{ width: "auto", height: "auto", maxWidth: "160px" }}
            />
          </div>

          {/* Login Form */}
          <form onSubmit={handleLogin} className="space-y-4">
            {/* Error Message */}
            {error && (
              <div
                className="text-center p-2 rounded"
                style={{
                  background: "#FEE",
                  color: "#D43F3A",
                  fontSize: "12px",
                  border: "1px solid #F5C6CB"
                }}
              >
                {error}
              </div>
            )}

            <div>
              <label
                htmlFor="username"
                className="block text-sm font-semibold mb-2"
                style={{ color: "#333333", fontSize: "13px" }}
              >
                Kullanıcı Adı
              </label>
              <div className="relative">
                <Input
                  id="username"
                  type="text"
                  value={username}
                  onChange={(e: React.ChangeEvent<HTMLInputElement>) => {
                    setUsername(e.target.value);
                    setError("");
                  }}
                  placeholder="Kullanıcı Adı"
                  className="pr-10"
                  style={{
                    borderColor: "#D5D5D5",
                    borderRadius: "3px",
                    fontSize: "13px",
                    backgroundColor: "#FAFAFA",
                    padding: "8px 35px 8px 12px",
                    height: "38px"
                  }}
                />
                <User
                  className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4"
                  style={{ color: "#999999" }}
                />
              </div>
            </div>

            <div>
              <label
                htmlFor="password"
                className="block text-sm font-semibold mb-2"
                style={{ color: "#333333", fontSize: "13px" }}
              >
                Parola
              </label>
              <div className="relative">
                <Input
                  id="password"
                  type="password"
                  value={password}
                  onChange={(e: React.ChangeEvent<HTMLInputElement>) => {
                    setPassword(e.target.value);
                    setError("");
                  }}
                  placeholder="Parola"
                  className="pr-10"
                  style={{
                    borderColor: "#D5D5D5",
                    borderRadius: "3px",
                    fontSize: "13px",
                    backgroundColor: "#FAFAFA",
                    padding: "8px 35px 8px 12px",
                    height: "38px"
                  }}
                />
                <Lock
                  className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4"
                  style={{ color: "#999999" }}
                />
              </div>
            </div>

            {/* Buttons */}
            <div className="flex gap-2 pt-2">
              <Button
                type="submit"
                className="flex-1 text-white font-semibold"
                style={{
                  background: "#4A8FBA",
                  borderRadius: "3px",
                  padding: "10px",
                  fontSize: "13px",
                  height: "38px"
                }}
              >
                Giriş
              </Button>

              <Button
                type="button"
                className="text-white font-semibold flex items-center justify-center gap-2"
                style={{
                  background: "#D43F3A",
                  borderRadius: "3px",
                  padding: "8px 16px",
                  fontSize: "11px",
                  height: "38px",
                  whiteSpace: "nowrap"
                }}
              >
                <svg viewBox="0 0 24 24" className="w-5 h-5" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <ellipse cx="12" cy="12" rx="9" ry="9" stroke="white" strokeWidth="2" transform="rotate(-20 12 12)"/>
                  <text x="12" y="16" textAnchor="middle" fill="white" fontSize="12" fontWeight="bold" fontStyle="italic">e</text>
                </svg>
                e-Devlet ile Giriş
              </Button>
            </div>

            {/* Forgot Password Link */}
            <div className="text-center pt-2">
              <a
                href="#"
                className="text-sm"
                style={{ color: "#4A8FBA", fontSize: "12px" }}
              >
                Giriş yapamıyor musunuz ?
              </a>
            </div>
          </form>

          {/* Social Media Icons */}
          <div className="flex justify-center gap-4 mt-6 pt-4">
            <a
              href="https://www.instagram.com/hitukurumsal/"
              target="_blank"
              rel="noopener noreferrer"
              className="hover:opacity-70 transition-opacity"
            >
              <svg viewBox="0 0 24 24" className="w-7 h-7" fill="#5A7FA3">
                <path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z"/>
              </svg>
            </a>
            <a
              href="https://www.facebook.com/HituKurumsal/"
              target="_blank"
              rel="noopener noreferrer"
              className="hover:opacity-70 transition-opacity"
            >
              <svg viewBox="0 0 24 24" className="w-7 h-7" fill="#5A7FA3">
                <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/>
              </svg>
            </a>
            <a
              href="https://twitter.com/hitukurumsal"
              target="_blank"
              rel="noopener noreferrer"
              className="hover:opacity-70 transition-opacity"
            >
              <Image
                src="https://ext.same-assets.com/1851312571/2046311093.png"
                alt="X"
                width={28}
                height={28}
                style={{ opacity: 0.7 }}
              />
            </a>
            <a
              href="https://www.youtube.com/user/hitituniv"
              target="_blank"
              rel="noopener noreferrer"
              className="hover:opacity-70 transition-opacity"
            >
              <svg viewBox="0 0 24 24" className="w-7 h-7" fill="#5A7FA3">
                <path d="M23.498 6.186a3.016 3.016 0 0 0-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 0 0 .502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 0 0 2.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 0 0 2.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814zM9.545 15.568V8.432L15.818 12l-6.273 3.568z"/>
              </svg>
            </a>
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer
        className="py-3 px-4 text-white text-xs flex flex-wrap justify-between items-center gap-2"
        style={{ background: "rgba(0,0,0,0.15)", fontSize: "11px" }}
      >
        <span>Üniversite Bilgi Yönetim Sistemi © 2025 <a href="#" style={{ color: "#A8D5FF" }}>UBYS</a>, Tüm Hakları Saklıdır.</span>
        <div className="flex gap-4">
          <a href="#" className="hover:underline">Telefon Rehberi</a>
          <a href="#" className="hover:underline">Web Sayfası</a>
          <a href="#" className="hover:underline">UBYS Destek</a>
          <a href="#" className="hover:underline">Kurumsal Değerlendirme</a>
        </div>
      </footer>
    </div>
  );
}
